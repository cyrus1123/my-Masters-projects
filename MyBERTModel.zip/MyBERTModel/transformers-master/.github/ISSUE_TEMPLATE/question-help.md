---
name: "❓ Questions & Help"
about: Post your general questions on the Hugging Face forum: https://discuss.huggingface.co/
title: ''
labels: ''
assignees: ''

---

# ❓ Questions & Help

<!-- The GitHub issue tracker is primarly intended for bugs, feature requests,
     new models, benchmarks, and migration questions. For all other questions,
     we direct you to the Hugging Face forum: https://discuss.huggingface.co/ .
     -->

## Details

<!-- Description of your issue -->

<!-- You should first ask your question on the forum, and only if
     you didn't get an answer after a few days ask it here on GitHub. -->

**A link to original question on the forum**:

<!-- Your issue will be closed if you don't fill this part. -->