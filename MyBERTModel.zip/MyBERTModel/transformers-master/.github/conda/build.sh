$PYTHON setup.py install     # Python command to install the script.
