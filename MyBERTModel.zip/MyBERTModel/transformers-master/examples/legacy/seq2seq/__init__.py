import os
import sys


sys.path.insert(1, os.path.dirname(os.path.realpath(__file__)))
